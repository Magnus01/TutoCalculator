describe("Task C3Q1", function () {  
    it("Test the operators for the value of the exponent precedence", function () {
    
        
        expect(operators["^"].precedence).toBe(4);
    });
});