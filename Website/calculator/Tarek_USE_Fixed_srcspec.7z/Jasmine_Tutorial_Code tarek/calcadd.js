describe("Task 1", function () {  
    it("should add two numbers together", function () {
        expect(add(1, 2)).toBe(3);
    });
});