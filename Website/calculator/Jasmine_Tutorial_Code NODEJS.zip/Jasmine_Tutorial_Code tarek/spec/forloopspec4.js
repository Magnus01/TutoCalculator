describe("Task 1", function () {  
    it("should add two numbers together", function () {
        expect(Count()).value).toBe(3);
    });
});