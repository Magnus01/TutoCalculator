describe("Task C3Q1", function () {  
    it("check to see if it's a number", function () {
        expect(isNumeric(3)).toBe(true);
    });
});