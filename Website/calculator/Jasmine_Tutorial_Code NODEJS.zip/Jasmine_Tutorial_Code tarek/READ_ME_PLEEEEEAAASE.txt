************All right Folks, here what i've done so far***************



1/ Test the node.js commands on the shell, but outside the AppData folder : it works. Its works also, in the www folder, which is nice.

       first problem tho: when the calculator.js' content is a wrong answer, the XML file isn't created. 



2/Use the chdir function to change directory folder with php : it works with relative and absolute paths.


3/Use the exec and shell_exec to execute command on php : it works, i could change the content of a text file, it's working even when you change the directory folder.


4/Test the node.js command with php. Nothin'. I've tried it while changing the directory folder in test11.php,
 I've created a test19.php in the same location of jasmine, didn't work either... I've tried many diferent way of writing,but nothin worked.


    second problem : node.js commands don't seem to work in a php file... We have to find an another way. ( special file, special way of writing, work with node.js and give up with php...)


//The code i've changed and tested is in the test11.php, but i've put a clone of it called test19.php, in the same folder as jasmine.js
//Sorry for the inconvenience bro

