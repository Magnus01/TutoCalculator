function isNumeric(x){
    return !isNaN(parseFloat(x)) && isFinite(x);
}

//console.log("isNumeric", n)
