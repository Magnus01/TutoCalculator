//!javascript
// calculator.js
exports.multiply = function(mul1, mul2)
{
    return mul1 * mul2;
};

exports.add = function(add1, add2)
{
    return add1 + add2;
};
